<?php
require_once('functions.php')//getting the functions.php this will allow us to reuse our functions later.
?>