 <footer>
    &copy; <?php echo date('Y');//sends the current date the browser being used as a place holder?>
    </footer>
    </body>
</html>